"""
OCR Service
Extracts text from images and PDFs using PaddleOCR (primary) with the
Google Cloud Vision REST API as a fallback.
"""
import base64
import logging
import os
from pathlib import Path

import httpx
from PIL import Image

from app.core.config import settings

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────
# PaddleOCR (primary engine)
# ─────────────────────────────────────────────────────────────────────────
_paddle_ocr = None

# PaddleOCR's language codes don't line up 1:1 with ISO codes; map the ones
# we're likely to see via OCR_LANGUAGE to the codes PaddleOCR expects.
_PADDLE_LANG_MAP = {
    "en": "en",
    "hi": "hi",
    "ch": "ch",
    "zh": "ch",
    "fr": "french",
    "de": "german",
    "ko": "korean",
    "ja": "japan",
}


def _paddle_lang() -> str:
    lang = (settings.OCR_LANGUAGE or "en").lower()
    return _PADDLE_LANG_MAP.get(lang, "en")


def _get_paddle_ocr():
    """Lazy-load the PaddleOCR engine (downloads/loads model weights on first use)."""
    global _paddle_ocr
    if _paddle_ocr is None:
        try:
            from paddleocr import PaddleOCR
            _paddle_ocr = PaddleOCR(use_angle_cls=True, lang=_paddle_lang(), show_log=False)
            logger.info("PaddleOCR engine initialised")
        except Exception as e:
            logger.warning(f"PaddleOCR unavailable: {e}")
    return _paddle_ocr


def _extract_with_paddle(image_path: str) -> str:
    ocr = _get_paddle_ocr()
    if not ocr:
        return ""

    result = ocr.ocr(image_path, cls=True)

    lines = []
    for page in result or []:
        for detection in page or []:
            # detection = [box_points, (text, confidence)]
            try:
                text = detection[1][0]
            except (IndexError, TypeError):
                continue
            if text:
                lines.append(text)

    text = "\n".join(lines)
    if text.strip():
        logger.info(f"PaddleOCR extracted {len(lines)} lines ({len(text)} chars) from {image_path}")
    return text.strip()


# ─────────────────────────────────────────────────────────────────────────
# Google Cloud Vision OCR (fallback engine)
# ─────────────────────────────────────────────────────────────────────────
_GOOGLE_VISION_ENDPOINT = "https://vision.googleapis.com/v1/images:annotate"


def _extract_with_google_vision(image_path: str) -> str:
    """Fallback OCR using the Google Cloud Vision REST API (TEXT_DETECTION).

    Requires GOOGLE_VISION_API_KEY to be set (in .env or the environment).
    """
    api_key = os.getenv("GOOGLE_VISION_API_KEY") or settings.google_vision_api_key
    if not api_key:
        logger.warning("GOOGLE_VISION_API_KEY not set; skipping Google Vision fallback")
        return ""

    try:
        with open(image_path, "rb") as f:
            image_content = base64.b64encode(f.read()).decode("utf-8")

        payload = {
            "requests": [
                {
                    "image": {"content": image_content},
                    "features": [{"type": "TEXT_DETECTION"}],
                }
            ]
        }

        resp = httpx.post(
            _GOOGLE_VISION_ENDPOINT,
            params={"key": api_key},
            json=payload,
            timeout=30.0,
        )
        resp.raise_for_status()
        data = resp.json()

        response_obj = (data.get("responses") or [{}])[0]
        if "error" in response_obj:
            logger.error(f"Google Vision API error: {response_obj['error']}")
            return ""

        text = response_obj.get("fullTextAnnotation", {}).get("text", "")
        if not text:
            text_annotations = response_obj.get("textAnnotations", [])
            text = text_annotations[0]["description"] if text_annotations else ""

        logger.info(f"Google Vision extracted {len(text)} chars from {image_path}")
        return text.strip()
    except Exception as e:
        logger.error(f"Google Vision OCR failed: {e}")
        return ""


# ─────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────
def extract_text_from_image(image_path: str) -> str:
    """Extract text using PaddleOCR with a Google Vision OCR fallback."""
    text = ""

    # Primary: PaddleOCR
    try:
        text = _extract_with_paddle(image_path)
        if text:
            return text
    except Exception as e:
        logger.warning(f"PaddleOCR failed: {e}")

    # Fallback: Google Cloud Vision
    text = _extract_with_google_vision(image_path)
    return text.strip()


def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract text from PDF pages (converts each page to image first)."""
    try:
        import pdf2image
        pages = pdf2image.convert_from_path(pdf_path, dpi=200)
        texts = []
        for i, page in enumerate(pages):
            tmp_path = pdf_path + f"_page_{i}.png"
            page.save(tmp_path, "PNG")
            texts.append(extract_text_from_image(tmp_path))
            os.remove(tmp_path)
        return "\n".join(texts)
    except Exception as e:
        logger.error(f"PDF text extraction failed: {e}")
        try:
            import pdfplumber
            with pdfplumber.open(pdf_path) as pdf:
                return "\n".join(p.extract_text() or "" for p in pdf.pages)
        except Exception as e2:
            logger.error(f"pdfplumber also failed: {e2}")
            return ""


def extract_text(file_path: str) -> str:
    """Route file to the appropriate extractor."""
    ext = Path(file_path).suffix.lower()
    if ext == ".pdf":
        return extract_text_from_pdf(file_path)
    else:
        return extract_text_from_image(file_path)
